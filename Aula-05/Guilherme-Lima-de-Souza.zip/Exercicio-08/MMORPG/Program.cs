﻿using System.IO.Pipes;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.Write("Digite o nome do seu Mago: ");
        string NameTag = Console.ReadLine();

        jogador.Nome = NameTag;
    }

    public class Personagem
    {
        public String Nome { get; set; }
        public int Nivel { get; set; }
        public int Forca { get; set; }
        public int Agilidade { get; set; }
        public int Vida { get; set; }
        public double Experiencia { get; set; }

    }

    public class Mago : Personagem
    {

    }

    public class Elfo : Personagem
    {

    }

    public class Cavaleiro : Personagem
    {

    }



}